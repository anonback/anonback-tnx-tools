<?php

// HotBot project for Dorking :D
// Coded in Morocco 27/11/2014 at 19:18 in my room xD
// Greetz to all codersleet members and  my friends
// dont change the rights ;)
// http://pastebin.com/u/magnom
//http://magsec.blogspot.com/2015/06/hotbot-auto-dorker.html

print "
+-----------------------------+
|      HotBot Dorking         |
|     coded by Mr.MaGnoM      |
|      CodersLeet Team        |
+-----------------------------+
";
echo "\n";

$ch1 =curl_init("http://www.hotbot.com/");
curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
$keyvoll = curl_exec($ch1);
curl_close($ch1);
$ma=preg_match("/\.val\('(.*?)'\);/",$keyvoll,$ke);

//echo $ke[1]."\n";
//$dork=urlencode($argv[1]);

// http://www.hotbot.com/search/web?pn=$i&q=$dork&keyvol=$ke[1]


$ch=curl_init();
for($i=1;$i<=30;$i++){
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch,CURLOPT_URL,"http://www.hotbot.com/search/web?pn=$i&q=powered+by+drupal+site%3aco&keyvol=$ke[1]"); // here ur dork  encoded use this site for encode ur dork http://urldecode.org/
curl_setopt($ch,CURLOPT_COOKIEFILE,'cookie.txt');
curl_setopt($ch,CURLOPT_COOKIEJAR,'cookie.txt');
curl_setopt($ch,CURLOPT_USERAGENT,'msnbot/1.0 (+http://search.msn.com/msnbot.htm)');
curl_setopt($ch,CURLOPT_ENCODING,"gzip, deflate, compress");
$data=curl_exec($ch);
preg_match_all('#<span class="web-baseuri">(.*?)</span>#',$data,$matches);
$links=array_unique($matches[1]);
//print_r($matches[1]);
$op=@fopen('result.html','a+');
foreach ($links as $ul){
  echo "http://".$ul."/"."\n";
  fwrite($op,"http://$ul/<br>");
}
fclose($op);

//if(!preg_match('#NO RESULTS FOUND#i',$data)) break;
}
?>
